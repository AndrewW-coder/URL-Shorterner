import json
import boto3
from collections import Counter

dynamodb = boto3.resource('dynamodb')
clicks_table = dynamodb.Table('clicks')
urls_table   = dynamodb.Table('urls')

def lambda_handler(event, context):
    params = event.get('queryStringParameters') or {}
    short_code = params.get('code')

    scan_kwargs = {}
    if short_code:
        scan_kwargs = {
            'FilterExpression': 'short_code = :sc',
            'ExpressionAttributeValues': {':sc': short_code}
        }

    items = clicks_table.scan(**scan_kwargs).get('Items', [])

    countries = Counter(i.get('country', 'Unknown') for i in items)
    devices   = Counter(i.get('device',  'Unknown') for i in items)
    browsers  = Counter(i.get('browser', 'Unknown') for i in items)

    urls = urls_table.scan().get('Items', [])
    url_list = sorted([
        {'short_code': u['short_code'],
         'long_url':   u['long_url'],
         'clicks':     int(u.get('click_count', 0))}
        for u in urls
    ], key=lambda x: x['clicks'], reverse=True)

    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'total_clicks':  len(items),
            'top_countries': dict(countries.most_common(5)),
            'devices':       dict(devices),
            'browsers':      dict(browsers),
            'top_urls':      url_list[:10]
        })
    }